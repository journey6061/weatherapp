import React from 'react'

const Fav =()=>{
    return(
    <div>this is fav</div>
    )
}

export default Fav