import React from 'react'

const Future =()=>{
    return(
    <div>this is future</div>
    )
}

export default Future