import React from 'react'

const Now =(props)=>{
    return(
    <div>this is now {props.weather}</div>
    )
}

export default Now